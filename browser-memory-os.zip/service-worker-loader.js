import './assets/index.ts-C0SyDN_G.js';
